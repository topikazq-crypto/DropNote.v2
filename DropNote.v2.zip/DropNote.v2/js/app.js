/* ===============================
   APP ROUTER (FINAL)
   =============================== */

const app = document.getElementById("app");

// ROUTER (GLOBAL)
window.loadPage = function (page) {
  fetch(`pages/${page}.html`)
    .then(res => {
      if (!res.ok) throw new Error("Page not found: " + page);
      return res.text();
    })
    .then(html => {
      // Inject page
      app.innerHTML = html;

      // Hapus script page lama
      document
        .querySelectorAll("script[data-page-script]")
        .forEach(s => s.remove());

      // Tentukan script page
      let scriptSrc = null;

      if (page === "home") scriptSrc = "js/home.js";
      if (page === "notes") scriptSrc = "js/notes.js";
      if (page === "editor") scriptSrc = "js/editor.js";
      if (page === "detail") scriptSrc = "js/detail.js";
      if (page === "wallet") scriptSrc = "js/wallet.js";
      if (page === "settings") scriptSrc = "js/settings.js";

      // Load script page
      if (scriptSrc) {
        const script = document.createElement("script");
        script.src = scriptSrc;
        script.dataset.pageScript = page;
        document.body.appendChild(script);
      }
    })
    .catch(err => {
      app.innerHTML = "<p style='padding:16px'>Error loading page</p>";
      console.error(err);
    });
};

// DEFAULT PAGE
loadPage("home");