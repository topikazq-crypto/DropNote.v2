/* ===============================
   HOME DASHBOARD (FINAL)
   =============================== */

function initHome() {
  const notes = getNotes();
  if (!Array.isArray(notes)) return;

  const now = Date.now();
  const OVERDUE_LIMIT = 1000 * 60 * 60 * 24 * 3;

  // ===============================
  // FILTER NOTES
  // ===============================
  const draftNotes = notes.filter(n => n.status === "Draft");
  const overdueNotes = draftNotes.filter(
    n => now - (n.updatedAt || n.createdAt) > OVERDUE_LIMIT
  );

  // ===============================
  // COUNTS
  // ===============================
  const draftCountEl = document.getElementById("draftCount");
  const overdueCountEl = document.getElementById("overdueCount");

  if (draftCountEl) draftCountEl.textContent = draftNotes.length;
  if (overdueCountEl) overdueCountEl.textContent = overdueNotes.length;

  // ===============================
  // NEXT ACTION (KERJAKAN SEKARANG)
  // ===============================
  const nextActionWrap = document.getElementById("nextAction");
  const nextActionCard = document.getElementById("nextActionCard");

  if (nextActionWrap && nextActionCard) {
    const target =
      [...overdueNotes].sort((a, b) => a.updatedAt - b.updatedAt)[0] ||
      [...draftNotes].sort((a, b) => a.updatedAt - b.updatedAt)[0];

    if (target) {
      nextActionWrap.classList.remove("hidden");

      nextActionCard.innerHTML = `
        <strong>${target.title}</strong>
        <div class="note-meta">
          ${timeAgo(target.updatedAt || target.createdAt)}
        </div>
      `;

      nextActionCard.onclick = () => {
        sessionStorage.setItem("editNoteId", target.id);
        loadPage("editor");
      };
    } else {
      nextActionWrap.classList.add("hidden");
    }
  }

  // ===============================
  // LAST UPDATE
  // ===============================
  const lastUpdateEl = document.getElementById("lastUpdate");
  if (notes.length && lastUpdateEl) {
    const latest = [...notes].sort(
      (a, b) => (b.updatedAt || 0) - (a.updatedAt || 0)
    )[0];

    lastUpdateEl.textContent =
      timeAgo(latest.updatedAt || latest.createdAt);
  }

  // ===============================
  // CONTINUE DRAFT BUTTON
  // ===============================
  const continueBtn = document.getElementById("continueBtn");
  if (continueBtn && draftNotes.length) {
    const latestDraft = [...draftNotes].sort(
      (a, b) => (b.updatedAt || 0) - (a.updatedAt || 0)
    )[0];

    continueBtn.disabled = false;
    continueBtn.onclick = () => {
      sessionStorage.setItem("editNoteId", latestDraft.id);
      loadPage("editor");
    };
  }
}

// AUTO INIT
initHome();