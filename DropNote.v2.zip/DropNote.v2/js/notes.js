/* ===============================
   NOTES PAGE (FINAL SMART FILTER)
   =============================== */

(() => {
  const list = document.getElementById("notesList");
  const addBtn = document.getElementById("addNoteBtn");
  const searchInput = document.getElementById("searchInput");
  const filterBtns = document.querySelectorAll(".status-filter button");

  let allNotes = [];
  let activeStatus = "all";

  // ===============================
  // LOAD FILTER STATE (PERSIST)
  // ===============================
  const savedFilter = sessionStorage.getItem("notesFilter");
  if (savedFilter) {
    activeStatus = savedFilter;
  }

  // ===============================
  // RENDER NOTES
  // ===============================
  function renderNotes(notes) {
    if (!list) return;
    list.innerHTML = "";

    if (notes.length === 0) {
      list.innerHTML = "<p class='empty'>Tidak ada catatan</p>";
      return;
    }

    notes.forEach(note => {
      const card = document.createElement("div");
      const stateInfo = getNoteState(note);

      card.className = `note-card note-${stateInfo.state}`;
      card.dataset.id = note.id;

      card.innerHTML = `
        <div class="note-head">
          <h3>${note.title}</h3>
          <button class="delete-btn" data-id="${note.id}">🗑️</button>
        </div>

        ${note.wallet ? `<div class="note-wallet">🔗 ${note.wallet}</div>` : ""}

        ${
          note.tags?.length
            ? `<div class="note-tags">
                ${note.tags
                  .map(tag => `<span class="tag" data-tag="${tag}">#${tag}</span>`)
                  .join(" ")}
              </div>`
            : ""
        }

        <div class="note-meta">
          ${stateInfo.label} • ${timeAgo(note.updatedAt)}
        </div>
      `;

      // OPEN DETAIL
      card.onclick = () => {
        sessionStorage.setItem("editNoteId", note.id);
        loadPage("detail");
      };

      // TAP FEEDBACK
      card.addEventListener("mousedown", () => card.style.opacity = "0.85");
      card.addEventListener("mouseup", () => card.style.opacity = "1");
      card.addEventListener("mouseleave", () => card.style.opacity = "1");

      // TAG CLICK → AUTO FILTER
      card.querySelectorAll(".tag").forEach(tagEl => {
        tagEl.onclick = (e) => {
          e.stopPropagation();

          const tag = tagEl.dataset.tag;
          searchInput.value = tag;

          activeStatus = "all";
          filterBtns.forEach(b => b.classList.remove("active"));
          filterBtns[0]?.classList.add("active");

          applyFilter();
        };
      });

      list.appendChild(card);
    });

    // DELETE
    document.querySelectorAll(".delete-btn").forEach(btn => {
      btn.onclick = (e) => {
        e.stopPropagation();
        const id = Number(btn.dataset.id);
        if (confirm("Hapus catatan ini?")) {
          deleteNote(id);
        }
      };
    });
  }

  // ===============================
  // FILTER + SEARCH
  // ===============================
  function applyFilter() {
    const q = searchInput ? searchInput.value.toLowerCase() : "";

    const filtered = allNotes.filter(note => {
      const matchText =
        note.title?.toLowerCase().includes(q) ||
        note.content?.toLowerCase().includes(q) ||
        note.wallet?.toLowerCase().includes(q) ||
        note.tags?.join(" ").toLowerCase().includes(q);

      const state = getNoteState(note).state;

      const matchStatus =
        activeStatus === "all" || state === activeStatus.toLowerCase();

      return matchText && matchStatus;
    });

    renderNotes(filtered);
  }

  // ===============================
  // LOAD NOTES
  // ===============================
  function loadNotes() {
    allNotes = sortNotesSmart(getNotes());
    applyFilter();
  }

  // ===============================
  // EVENTS
  // ===============================
  if (searchInput) {
    searchInput.oninput = applyFilter;
  }

  filterBtns.forEach(btn => {
    btn.onclick = () => {
      filterBtns.forEach(b => b.classList.remove("active"));
      btn.classList.add("active");

      activeStatus = btn.dataset.status;
      sessionStorage.setItem("notesFilter", activeStatus);

      applyFilter();
    };
  });

  if (addBtn) {
    addBtn.onclick = () => {
      sessionStorage.removeItem("editNoteId");
      loadPage("editor");
    };
  }

  window.addEventListener("notes:updated", loadNotes);

  // INIT
  loadNotes();
})();