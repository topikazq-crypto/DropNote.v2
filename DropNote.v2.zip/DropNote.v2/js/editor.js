/* ===============================
   EDITOR (CREATE & EDIT NOTE)
   FINAL & LOGIC FIX 🔒
   =============================== */

(() => {
  const waitDom = () => {
    const saveBtn = document.getElementById("saveBtn");
    if (!saveBtn) {
      requestAnimationFrame(waitDom);
      return;
    }

    const titleInput = document.getElementById("titleInput");
    const walletInput = document.getElementById("linkInput");
    const tagInput = document.getElementById("tagsInput");
    const contentInput = document.getElementById("contentInput");

    const editId = sessionStorage.getItem("editNoteId");

    /* ===============================
       AUTO RESIZE TEXTAREA (UX)
       =============================== */
    const autoResize = el => {
      el.style.height = "auto";
      el.style.height = el.scrollHeight + "px";
    };

    contentInput.addEventListener("input", () =>
      autoResize(contentInput)
    );

    /* ===============================
       LOAD EDIT MODE
       =============================== */
    let editingNote = null;

    if (editId) {
      editingNote = getNotes().find(
        n => String(n.id) === String(editId)
      );

      if (editingNote) {
        titleInput.value = editingNote.title || "";
        walletInput.value = editingNote.wallet || "";
        tagInput.value = (editingNote.tags || []).join(", ");
        contentInput.value = editingNote.content || "";

        setTimeout(() => autoResize(contentInput), 0);
      }
    }

    /* ===============================
       SAVE HANDLER (FINAL)
       =============================== */
    saveBtn.onclick = () => {
      const title = titleInput.value.trim();
      if (!title) {
        alert("Judul wajib diisi");
        return;
      }

      const wallet = walletInput.value.trim();
      const tags = tagInput.value
        .split(",")
        .map(t => t.trim())
        .filter(Boolean);

      const content = contentInput.value.trim();

      /* ===============================
         UPDATE EXISTING NOTE
         =============================== */
      if (editId && editingNote) {
        updateNote(editId, {
          title,
          wallet,
          tags,
          content,
          // 🔑 LOGIC FIX: Draft → Active saat diedit
          status:
            editingNote.status === "Draft"
              ? "Active"
              : editingNote.status
        });

        sessionStorage.removeItem("editNoteId");
      }

      /* ===============================
         CREATE NEW NOTE
         =============================== */
      else {
        addNote({
          title,
          wallet,
          tags,
          content,
          status: "Draft"
        });
      }

      loadPage("notes");
    };
  };

  waitDom();
})();