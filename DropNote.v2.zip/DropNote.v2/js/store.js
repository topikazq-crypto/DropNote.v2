/* ===============================
   DROPNOTE STORE (FINAL LOGIC)
   =============================== */

const STORE_KEY = "dropnote_notes";

/* ===============================
   MIGRATION (AMAN DATA LAMA)
   =============================== */
(function migrateNotes() {
  const raw = JSON.parse(localStorage.getItem(STORE_KEY)) || [];

  const migrated = raw.map(n => {
    const now = Date.now();
    return {
      id: n.id || now,
      title: n.title || "",
      wallet: n.wallet || "",
      tags: n.tags || [],
      content: n.content || "",
      status: n.status || "Draft",
      createdAt: n.createdAt || now,
      updatedAt: n.updatedAt || now,
      startedAt: n.startedAt ?? null,     // 🔥 PENANDA DIKERJAKAN
      completedAt: n.completedAt ?? null
    };
  });

  localStorage.setItem(STORE_KEY, JSON.stringify(migrated));
})();

/* ===============================
   CORE
   =============================== */
function getNotes() {
  return JSON.parse(localStorage.getItem(STORE_KEY)) || [];
}

function saveNotes(notes) {
  localStorage.setItem(STORE_KEY, JSON.stringify(notes));
}

/* ===============================
   EVENT SYNC
   =============================== */
function emitNotesUpdated() {
  window.dispatchEvent(new Event("notes:updated"));
}

/* ===============================
   CRUD
   =============================== */

// CREATE
function addNote(note) {
  const notes = getNotes();
  const now = Date.now();

  notes.unshift({
    id: now,
    title: note.title || "",
    wallet: note.wallet || "",
    tags: note.tags || [],
    content: note.content || "",
    status: "Draft",
    createdAt: now,
    updatedAt: now,
    startedAt: null,
    completedAt: null
  });

  saveNotes(notes);
  emitNotesUpdated();
}

// UPDATE (KUNCI LOGIKA ACTIVE)
function updateNote(id, data) {
  const notes = getNotes();
  const index = notes.findIndex(n => String(n.id) === String(id));
  if (index === -1) return;

  const note = notes[index];

  notes[index] = {
    ...note,
    ...data,
    updatedAt: Date.now(),
    startedAt: note.startedAt || Date.now() // 🔥 SAVE PERTAMA = ACTIVE
  };

  saveNotes(notes);
  emitNotesUpdated();
}

// DELETE
function deleteNote(id) {
  const notes = getNotes().filter(n => String(n.id) !== String(id));
  saveNotes(notes);
  emitNotesUpdated();
}

/* ===============================
   GLOBAL EXPOSE (WAJIB)
   =============================== */
window.getNotes = getNotes;
window.addNote = addNote;
window.updateNote = updateNote;
window.deleteNote = deleteNote;