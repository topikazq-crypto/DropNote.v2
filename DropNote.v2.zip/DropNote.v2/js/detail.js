/* ===============================
   DETAIL NOTE VIEW
   =============================== */

(() => {
  const waitDom = () => {
    const titleEl = document.getElementById("detailTitle");
    if (!titleEl) {
      requestAnimationFrame(waitDom);
      return;
    }

    const id = sessionStorage.getItem("editNoteId");
    if (!id) {
      loadPage("notes");
      return;
    }

    const note = getNotes().find(n => String(n.id) === String(id));
    if (!note) {
      loadPage("notes");
      return;
    }

    // ===============================
    // RENDER CONTENT
    // ===============================
    document.getElementById("detailTitle").textContent = note.title;

    document.getElementById("detailMeta").textContent =
      `${note.status} • ${timeAgo(note.updatedAt)}`;

    document.getElementById("detailContent").textContent =
      note.content || "";

    // ===============================
    // DONE / UNDO DONE
    // ===============================
    const toggleBtn = document.getElementById("toggleDoneBtn");
    const isDone = !!note.completedAt;

    toggleBtn.textContent = isDone ? "↩️ Undo Done" : "✔️ Mark Done";

    toggleBtn.onclick = () => {
      updateNote(note.id, {
        completedAt: isDone ? null : Date.now(),
        status: isDone ? "Draft" : "Done"
      });

      loadPage("detail"); // refresh
    };

    // ===============================
    // EDIT
    // ===============================
    document.getElementById("editBtn").onclick = () => {
      loadPage("editor");
    };

    // ===============================
    // DELETE
    // ===============================
    document.getElementById("deleteBtn").onclick = () => {
      if (confirm("Catatan ini akan dihapus permanen")) {
        deleteNote(note.id);
        sessionStorage.removeItem("editNoteId");
        loadPage("notes");
      }
    };
  };

  waitDom();
})();