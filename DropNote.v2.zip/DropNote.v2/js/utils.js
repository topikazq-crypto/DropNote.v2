/* ===============================
   UTILITIES (FINAL & STABLE)
   =============================== */

// ===============================
// TIME AGO
// ===============================
function timeAgo(timestamp) {
  if (!timestamp) return "";
  const diff = Date.now() - timestamp;

  const min = Math.floor(diff / 60000);
  const hour = Math.floor(diff / 3600000);
  const day = Math.floor(diff / 86400000);

  if (day > 0) return `${day} hari lalu`;
  if (hour > 0) return `${hour} jam lalu`;
  if (min > 0) return `${min} menit lalu`;
  return "baru saja";
}

// ===============================
// STATUS FROM TAGS (LOGIC CORE)
// ===============================
function statusFromTags(tags = []) {
  const t = tags.map(v => v.toLowerCase());

  if (t.includes("done")) return "Done";
  if (t.includes("active")) return "Active";
  if (t.includes("draft")) return "Draft";

  return null;
}

// ===============================
// NOTE STATE ENGINE
// ===============================
function getNoteState(note) {
  const now = Date.now();

  if (note.completedAt) {
    return { state: "done", label: "Selesai" };
  }

  const age = now - (note.updatedAt || note.createdAt);
  const threeDays = 1000 * 60 * 60 * 24 * 3;

  if (note.status === "Draft" && age > threeDays) {
    return { state: "overdue", label: "⚠️ Overdue" };
  }

  if (note.status === "Draft") {
    return { state: "draft", label: "Draft" };
  }

  return { state: "active", label: "Active" };
}

// ===============================
// SMART SORT
// ===============================
function sortNotesSmart(notes) {
  return [...notes].sort((a, b) => {
    const p = { overdue: 1, active: 2, draft: 3, done: 4 };
    const aS = getNoteState(a).state;
    const bS = getNoteState(b).state;

    if (p[aS] !== p[bS]) return p[aS] - p[bS];
    return (a.updatedAt || 0) - (b.updatedAt || 0);
  });
}

// ===============================
// GLOBAL EXPOSE
// ===============================
window.timeAgo = timeAgo;
window.statusFromTags = statusFromTags;
window.getNoteState = getNoteState;
window.sortNotesSmart = sortNotesSmart;